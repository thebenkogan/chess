# OCaml Chess

Final Project for CS 3110, Fall 2021.

Team members: Ben Kogan, Nick Runje, Kyle Fowler, and Aariz Faisal.

# Description

Two player chess game that can be played on two different computers. Have some fun playing chess! 
